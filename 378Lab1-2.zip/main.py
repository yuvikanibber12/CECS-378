#defining encoded key and string. 
def encode(key, string):
encoded_chars = []
for a in range(len(string)):
key_b = key[a % len(key)]
encoded_b = chr(ord(string[a]) + ord(key_b) % 256)
encoded_chars.append(encoded_b)
encoded_string = "".join(encoded_chars)
return encoded_string
  #Inputing the phrase. This is the encrypted phrase. 
string=input("enter a phrase to encrypt: ")
key="dgeufuvvwu"
print("The ecrypted phrase is ",encode(key,string))

#Writing the program for decrypting. 
#Defining the decoded key and string and returning the decoded string. 
#Enter the phrase that is to be decrypted and print results. 
#use the key defined for the results and alphabets to be used to decrypt. 
Program for decryption:


def decode(key, string):
decoded_chars = []
for a in range(len(string)):
key_b = key[a % len(key)]
decoded_b = chr(ord(string[a]) - ord(key_b) % 256)
decoded_chars.append(decoded_b)
decoded_string = "".join(decoded_chars)
return decoded_string

string=input("What phase do you want to decrypt?")
key="dgeufuvvwu"
print("The decrypted phrase is "decode(key,e))

Key =dgeufuvvwu