#Yuvika Nibber
#Decrypting the phrase
#defining
def decrypt(a,key):
answer = " "
#All the aphabets 
string = "abcdefghijklmnopqrstuvwxyz"
a = "string" 
#For loop and if statement for the string of 26 alphabets and return the answer. 
for i in range(len(a)):
  if a[i] == ' ':
    answer = answer+a[i]
    continue
for m in range(len(string)):
  if a[i] == string[m]:
    b = m + key
index = (m + key) % 26
if b < 0:
    index = 26 + b
    answer = answer + string[index]
    return answer

#decryption
key = int(input("Enter a key: "))
#enter the given encrypted phases and run decrypt command. 
#print results. 
input1 = "fqjcb rwjwj vnjax bnkhj whxcq nawjv nfxdu mbvnu ujbbf nnc"
print(decrypt(input1,key))
print("----------------------------------------------------------------------------")
input1 = "oczmz vmzor jocdi bnojv dhvod igdaz admno ojbzo rcvot jprvi oviyv aozmo cvooj ziejt dojig toczr dnzno jahvi fdiyv xcdzq zoczn zxjiy"
print(decrypt(input1,key))
print("----------------------------------------------------------------------------")
input1 = "ejitp spawa qleji taiul rtwll rflrl laoat wsqqj atgac kthls iraoa twlpl qjatw jufrh lhuts qataq itats aittk stqfj cae"
print(decrypt(input1,key))
print("----------------------------------------------------------------------------")
input1 = "iyhqz ewqin azqej shayz niqbe aheum hnmnj jaqii yuexq ayqkn jbeuq iihed yzhni ifnun sayiz yudhe sqshu qesqa iluym qkque aqaqm oejjs hqzyu jdzqa diesh niznj jayzy uiqhq vayzq shsnj jejjz nshna hnmyt isnae sqfun dqzew qiead zevqi zhnjq shqze udqai jrmtq uishq ifnun siiqa suoij qqfni syyle iszhn bhmei squih nimnx hsead shqmr udquq uaqeu iisqe jshnj oihyy snaxs hqihe lsilu ymhni tyz"
print(decrypt(input1,key))