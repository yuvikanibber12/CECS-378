//vuln.c
 #include <stdio.h>
 #include <string.h>
 int exploit(int argc, char **argv) {
 // Make some stack information
 char a[100], b[100], c[100], d[100];
 // Call the exploitable function
 int exploitable (const char *arg);
 // Return everything is OK
 return(0);
 }

 int exploitable (const char *arg) {
 // Make some stack space
 char buffer[10];
 // Now copy the bufferb
 strcpy(buffer, arg);
 printf("The buffer says .. [%s/%p].\n", buffer, &buffer);
 // Return everything fun
 return(0); }